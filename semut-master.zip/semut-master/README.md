 #print("Creative by")
    <br>"[1]Adipati arya")https://github.com/adipatiarya
    <br>"[2]Alberto anggi")https://github.com/albertoanggi/xl-py
    <br>"[3]Ardi Mr A_S")haijuga7@gmail.com
    <br>"[4]Kumpul4semut")https://github.com/kumpul4semut
    
    Easy install
    1.Download termux di play store
    2.ketik "pkg install python;pkg install git;git clone https://github.com/kumpul4semut/semut.git;cd semut;python dor.py"(tanpa tanda petik") lalu enter
